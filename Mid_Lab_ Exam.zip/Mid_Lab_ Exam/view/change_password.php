<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>change password</title>
</head>
<body>
    <form action="" method="POST" >
        <table align="center" cellspacing="0" border="1" cellpadding="5">
            <tr>
                <td>Your Id</td>
                <td>
                    <input type="text" name="id" id="">
                </td>
            </tr>
            <tr>
                <td>Current Password</td>
                <td>
                    <input type="password" name="password" id="">
                </td>
            </tr>
            <tr>
                <td>New Password</td>
                <td>
                    <input type="password" name="newpassword" id="">
                </td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <input type="submit" name="submit" value="Update Password" align="center">
                    <a href="#">Go Home?</a>
                </td>
            </tr>
        </table>                    
    </form>
</body>
</html>